rm *.o

g++ -o ifrit  evaluate.cpp history_heuristic.cpp  iterative_deepening.cpp killer_heuristic.cpp main.cpp make_move.cpp move_generation.cpp move_ordering.cpp platform.cpp pv_save.cpp search.cpp search_quiescence.cpp search_root.cpp test_chess_bitboard.cpp time_management.cpp transposition_table.cpp uci_engine_to_gui.cpp uci_fen_parser.cpp uci_go_parser.cpp uci_gui_to_engine.cpp zobrist_hashing.cpp -Wfatal-errors -w -s -pipe -Ofast -std=c99 -m64 -march=nocona -DNDEBUG -flto -fwhole-program -fpermissive








 



