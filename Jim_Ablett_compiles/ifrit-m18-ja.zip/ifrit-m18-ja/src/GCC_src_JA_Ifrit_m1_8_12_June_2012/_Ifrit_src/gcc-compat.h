
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#include "platform.h"

#if !defined(__GNUC__) && !defined(__MINGW32__)
#define _ANDROID 1

#endif


#if defined(__GNUC__) || defined(_ANDROID)  
#if !defined(__MINGW32__)

      #include <cstring>
      #include <unistd.h>
      #include <sys/time.h>

#endif     
#endif

#define U64(constantu64) constantu64##ULL


//typedef __int32 int32_t;
//typedef __int64 int64_t; 
//typedef __int16 int16_t;

#include <iostream>

using namespace std;

