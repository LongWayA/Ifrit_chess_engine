#ifdef _LINUX
      #include <cstring>
      #include <stdlib.h> 
      #include <stdio.h>
      #include <string.h>
      #include <unistd.h>
     
           
      typedef unsigned __int64 u64; 
      #define U64(constantu64) constantu64##ULL
     
     #endif

#include <iostream>    
 
using namespace std;    

