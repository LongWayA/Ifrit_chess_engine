rm *.o
icc -o ifrit *.cpp -w -Ot -march=athlon64 -msse -fasm-blocks -DNDEBUG -D_LINUX -lpthread -ldl -lm -unroll -vec -ipo -prof_gen







