


#include "linux-compat.h"


#include "constants_header.h"
#include "move_list_struct.h"



#define TEST_HISTORY 0 



namespace History_heuristic
{



	int32_t get_white_history
	(
		const uint8_t n,
		const uint8_t c 
	);

	
	int32_t get_black_history
	(
		const uint8_t n,
		const uint8_t c 
	);


	void ini_history();

	
	void white_history_good_save
	(
		const uint8_t i,
		struct List & list,
		const uint8_t depth,
		const uint8_t depth_max
	);

	
	void black_history_good_save
	(
		const uint8_t i,
		struct List & list,
		const uint8_t depth,
		const uint8_t depth_max
	);

	
	inline void white_history_bad_save
	(
		const uint8_t e,
		struct List & list,
		const uint8_t depth,
		const uint8_t depth_max
	);

	
	inline void black_history_bad_save
	(
		const uint8_t e,
		struct List & list,
		const uint8_t depth,
		const uint8_t depth_max
	);


#if TEST_HISTORY

	void History_heuristic::test_print
	(	
		const uint8_t depth_max
	);

#endif

};
