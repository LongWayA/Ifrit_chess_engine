rm *.o

g++ -o ifrit *.cpp -w -s -pipe -Ofast -std=c99 -m32 -DNDEBUG -fwhole-program -flto -fpermissive -D_LINUX








 



