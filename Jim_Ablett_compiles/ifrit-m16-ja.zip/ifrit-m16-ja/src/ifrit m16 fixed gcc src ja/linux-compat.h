
#include <stdint.h>

#include "platform.h"

#if defined(_LINUX) && !defined(__MINGW32__)
      #include <cstring>
      #include <stdlib.h>
      #include <stdio.h>
      #include <string.h>
      #include <unistd.h>
#include <sys/time.h>

      #define U64(constantu64) constantu64##ULL

     #else

 #define U64(constantu64) constantu64##ULL

#endif

#include <iostream>

using namespace std;

