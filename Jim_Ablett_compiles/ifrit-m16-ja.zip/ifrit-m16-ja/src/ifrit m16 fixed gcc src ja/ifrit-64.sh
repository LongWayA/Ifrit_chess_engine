rm *.o

g++ -o ifrit *.cpp -w -s -pipe -Ofast -std=c99 -m64 -march=nocona -DNDEBUG -fwhole-program -flto -fpermissive -D_LINUX








 



