rm *.o
icc -o ifrit *.cpp -w -Ot -march=pentiumpro -fasm-blocks -DNDEBUG -D_LINUX -lpthread -ldl -lm -static -unroll -vec -ipo -prof_gen







