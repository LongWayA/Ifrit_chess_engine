package Genie_shell_save;

import java.io.*;
//import java.util.jar.*;
//import java.util.zip.*;
// ������ �� ������ ���� �������
import Genie_shell.Genie_Chess_Board;


public class Partii_Disk {

public int sloi;
public int sloi_Max;

//
public int color_hoda[];
// �������������� ������ ������ �����<<<<<<<<<<<<<<<<<<<<<<<<<<
public   int Figure_Color[][][];
// �������������� ������>>>>>>>>>>>>>>>>>>>>>>>>>>>>
public char  Figure_Name[][][];
//
public int stop_rokirovka[][];

Genie_Chess_Board Chess_Board_o;

//����������� (�� ��� ��� ��� ������� ? :))
//==============================================================================
public  Partii_Disk(){
 Partii_Disk_ini();
}
//******************************************************************************

// �������������� ������ �.�. ������ ��������� ���������
//==============================================================================
public void Partii_Disk_ini(){
 sloi=0;
 sloi_Max=0;
 color_hoda = new int[500];
 Figure_Name= new char[500][8][8];
 Figure_Color= new int[500][8][8];
 stop_rokirovka= new int[500][8];
}
//******************************************************************************

// ���������� ������� ��������� �����
//==============================================================================
  public void Set_Snimok_Sostoiania(Genie_Chess_Board Chess_Board_o1) {
  this.Chess_Board_o=Chess_Board_o1;
  color_hoda[sloi] = Chess_Board_o.color_move;
   for (int y1=0 ; y1<8;y1++){
    for (int x1=0 ; x1<8;x1++){
       Figure_Color[sloi][y1][x1] = Chess_Board_o.Figure_Color[y1][x1];
    }
   }
   for (int y2=0 ; y2<8;y2++){
    for (int x2=0 ; x2<8;x2++){
      Figure_Name[sloi][y2][x2] = Chess_Board_o.Figure_Name[y2][x2];
    }
   }
  for (int x3=0 ; x3<8;x3++){
     stop_rokirovka[sloi][x3] = Chess_Board_o.stop_castling[x3];
  }
//  System.out.println("Set_Snimok_Sostoiania="+sloi);
  }
//******************************************************************************

// ���������� ����� ������� ����
//==============================================================================
  public Genie_Chess_Board Get_Snimok_Sostoiania() {

    Chess_Board_o.color_move = color_hoda[sloi] ;
      for (int y21=0 ; y21<8;y21++){
        for (int x21=0 ; x21<8;x21++){
         Chess_Board_o.Figure_Color[y21][x21]=Figure_Color[sloi][y21][x21] ;
      }
     }
      for (int y22=0 ; y22<8;y22++){
       for (int x22=0 ; x22<8;x22++){
         Chess_Board_o.Figure_Name[y22][x22]=Figure_Name[sloi][y22][x22] ;
     }
    }
       for (int x23=0 ; x23<8;x23++){
          Chess_Board_o.stop_castling[x23]=stop_rokirovka[sloi][x23];
       }
//    System.out.println("Get_Snimok_Sostoiania="+sloi);
     return this.Chess_Board_o;
  }
//******************************************************************************

//==============================================================================
public void VperedHodim(){
   if (sloi>499) sloi=499;
   sloi=sloi+1;
   sloi_Max=sloi;
//   System.out.println("VperedHodim="+sloi);
}
//******************************************************************************

//==============================================================================
public void Vpered(){
   sloi=sloi+1;
   if (sloi>sloi_Max) sloi=sloi_Max;
//   System.out.println("Vperedsloi="+sloi);
}
//******************************************************************************

//==============================================================================
public void Nazad(){
   sloi=sloi-1;
   if (sloi<0) sloi=0;
//   System.out.println("Nazadsloi="+sloi);
}
//******************************************************************************

//==============================================================================

public void Save_Partiu(String namePartia){
//	JarFile jarFile = new JarFile("And_chess_K.jar");
//  JarEntry jarEntry = new JarEntry("SavePartii/ZapisPartii");
//	FileOutputStream potok_partii_out = new FileOutputStream("SavePartii/ZapisPartii");
//	JarOutputStream potok_partii_out = jarFile.getEntry(jarEntry.getName()) ;			
   
    
 try{
 	FileOutputStream potok_partii_out = new FileOutputStream("SavedGame");

 //-----------------------------------------------
   for (int sloi_P=0 ; sloi_P<=sloi_Max;sloi_P++){
   	potok_partii_out.write(sloi_Max);
   	potok_partii_out.write(sloi_P);
   	potok_partii_out.write(color_hoda[sloi_P]);

        for (int yp1=0 ; yp1<8;yp1++){
    for (int xp1=0 ; xp1<8;xp1++){
    	potok_partii_out.write(Figure_Color[sloi_P][yp1][xp1]);
    }
   }

   for (int yp2=0 ; yp2<8;yp2++){
    for (int xp2=0 ; xp2<8;xp2++){
    	potok_partii_out.write((int) Figure_Name[sloi_P][yp2][xp2]);
    }
   }

   for (int xp3=0 ; xp3<8;xp3++){
   	potok_partii_out.write(stop_rokirovka[sloi_P][xp3]);
   }
   }//for (int sloi_P=0 ; sloi_P<=sloi_Max;sloi_P++)
 //-----------------------------------------------
   potok_partii_out.close();
   
  }catch(FileNotFoundException e){
   System.out.println("������ �������� ��������� �����");
  }catch(IOException e){
     System.out.println("�������� ������"+ e);
  }

// System.out.println("Save_Partiu");
}//Save_Partiu(String namePartia)
//******************************************************************************

//==============================================================================

public void Read_Partiu(String namePartia){
//	JarFile jarFile = new JarFile("And_chess_K.jar");
//	JarEntry jarEntry = new JarEntry("SavePartii/ZapisPartii");
//	InputStream potok_partii_in = jarFile.getInputStream(jarEntry);
	
	try{
	 FileInputStream potok_partii_in = new FileInputStream("SavedGame");
 //-----------------------------------------------
   for (int sloi_P=0 ; sloi_P<=sloi_Max;sloi_P++){
      sloi_Max= potok_partii_in.read()   ;
      sloi_P= potok_partii_in.read();
      color_hoda[sloi_P]=potok_partii_in.read();

        for (int yp1=0 ; yp1<8;yp1++){
    for (int xp1=0 ; xp1<8;xp1++){
    Figure_Color[sloi_P][yp1][xp1]=potok_partii_in.read();
    }
   }

   for (int yp2=0 ; yp2<8;yp2++){
    for (int xp2=0 ; xp2<8;xp2++){
     Figure_Name[sloi_P][yp2][xp2]=(char)potok_partii_in.read();
    }
   }

   for (int xp3=0 ; xp3<8;xp3++){
    stop_rokirovka[sloi_P][xp3]= potok_partii_in.read();
   }
   }//for (int sloi_P=0 ; sloi_P<=sloi_Max;sloi_P++)
 //-----------------------------------------------
   potok_partii_in.close();
  }catch(FileNotFoundException e){
   System.out.println("������ �������� ��������� �����");
  }catch(IOException e){
     System.out.println("�������� ������");
  }

// System.out.println("Read_Partiu");
}//Save_Partiu(String namePartia)
//******************************************************************************

}//class Partii_Disk
