/*
 * Created on 30.10.2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Genie_engine;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author �����
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Debug {
/*	
//	$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    System.out.println(Chess_Figure_Name[Depth][y_s][x_s]);	
    System.out.println(Chess_Figure_Color[Depth][y_s][x_s]);						   
    
	  for (int y=0;y<8;y++){	
	    System.out.println(Resolved_Moves[y][0]+" "+Resolved_Moves[y][1]+" "
	    		+Resolved_Moves[y][2]+" "+Resolved_Moves[y][3]+" "
	    		+Resolved_Moves[y][4]+" "+Resolved_Moves[y][5]+" "
	    		+Resolved_Moves[y][6]+" "+Resolved_Moves[y][7]+" "
	    );
	  } //for y		
	  System.out.println("----------------");	
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
		 System.out.println("Color_Move[0]="+Color_Move[0]);
		 System.out.println("Chess_Figure_Name[0][y_s][x_s]="+Chess_Figure_Name[0][y_s][x_s]);	
//		--------------------------------------
		  for (int y=0;y<8;y++){
		    for (int x=0;x<8;x++){
		    System.out.println("y="+y+" x="+x);	
		    
		    System.out.println("Resolved_Moves[0][y][x]="+Resolved_Moves[0][y][x]);
		   } // for x
		  } //for y		
			
//		--------------------------------------
 if (true)break;  
 
  switch (nameFigure[y][x]){
           case 'r' :
              ocenka= ocenka+zv*(5000+Pozicion[y][x]);
              break;
           case 'n' :
              ocenka= ocenka+zv*(3000+Pozicion[y][x]);
              break;
           case 'b' :
              ocenka= ocenka+zv*(3000+Pozicion[y][x]);
              break;
           case 'q' :
              ocenka= ocenka+zv*(9000+Pozicion[y][x]);
              break;
           case 'k' :
           	// ������ ���� ������ ���� ������ �� ����� :)
            //  not_eat=0;
            //  if (colorFigure[y][x]!=zvhoda) not_eat=100000;
           //   ocenka= ocenka+zv*(100000+Pozicion[y][x]+ not_eat);
           	ocenka= ocenka+zv*(100000+Pozicion[y][x]);
 	
	
/*				
//		---------------------------------------------------------    
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		     System.out.println("Node= "+Nodes);	
			 System.out.println("Depth= "+Depth);	
		     System.out.println("Figure_Name= "+Chess_Figure_Name[Depth][y_s][x_s]);	
		     System.out.println("Figure_Color= "+Chess_Figure_Color[Depth][y_s][x_s]);
		     System.out.println("y_s= "+y_s+" x_s= "+ x_s);
		   
			  for (int y=0;y<8;y++){							  
			    System.out.println(Chess_Figure_Name[Depth+1][y][0]+" "
			    		+Chess_Figure_Name[Depth+1][y][1]+" "
			    		+Chess_Figure_Name[Depth+1][y][2]+" "+Chess_Figure_Name[Depth+1][y][3]+" "
			    		+Chess_Figure_Name[Depth+1][y][4]+" "+Chess_Figure_Name[Depth+1][y][5]+" "
			    		+Chess_Figure_Name[Depth+1][y][6]+" "+Chess_Figure_Name[Depth+1][y][7]+" "
			    );
			  } //for y	
			  PV_m[Depth]=f[Depth]+" "+m1[Depth]+m2[Depth]+m3[Depth]+m4[Depth];	
			//  System.out.println("PV_m= "+PV_m[Depth]);
			  System.out.println("PV_m= "+PV_m[0]+" "+PV_m[1]+" "+PV_m[2]+" "+PV_m[3]
								+" "+PV_m[4]+" "+PV_m[5]);
			  System.out.println("----------------");
*/			  
/*			 
//		$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//			   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		     try{
		     	FileWriter_o.write("Node= "+Nodes);
		     	FileWriter_o.write('\n');
		     	FileWriter_o.write("Depth= "+Depth);	
		     	FileWriter_o.write('\n');
		     	FileWriter_o.write("Figure_Name= "+Chess_Figure_Name[Depth][y_s][x_s]);	
		     	FileWriter_o.write('\n');
		     	FileWriter_o.write("Figure_Color= "+Chess_Figure_Color[Depth][y_s][x_s]);
		     	FileWriter_o.write('\n');
		     	FileWriter_o.write("y_s= "+y_s+" x_s= "+ x_s);
		     	FileWriter_o.write('\n');
			   
				  for (int y=0;y<8;y++){							  
				  	FileWriter_o.write(Chess_Figure_Name[Depth+1][y][0]
					+" "+Chess_Figure_Name[Depth+1][y][1]+" "
				    +Chess_Figure_Name[Depth+1][y][2]+" "+Chess_Figure_Name[Depth+1][y][3]+" "
				    +Chess_Figure_Name[Depth+1][y][4]+" "+Chess_Figure_Name[Depth+1][y][5]+" "
				    +Chess_Figure_Name[Depth+1][y][6]+" "+Chess_Figure_Name[Depth+1][y][7]+" "
				    );
				  	FileWriter_o.write('\n');
				  } //for y	
				  PV_m[Depth]=f[Depth]+" "+m1[Depth]+m2[Depth]+m3[Depth]+m4[Depth];	
				//  System.out.println("PV_m= "+PV_m[Depth]);
				  FileWriter_o.write("PV_m= "+PV_m[0]+" "+PV_m[1]+" "+PV_m[2]+" "+PV_m[3]
									+" "+PV_m[4]+" "+PV_m[5]);
				  FileWriter_o.write('\n');
				  FileWriter_o.write("----------------");
				  FileWriter_o.write('\n');
			  	
			 
		     }catch(FileNotFoundException e){
		         System.out.println("������ �������� ��������� �����");
		    }catch(IOException e){
		         System.out.println("�������� ������"+ e);
		    }
			 
//		$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$    
	*/	
	
	/*
//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 	  	 
			  	PV_Export="PV_m= "+PV_m[0]+" "+PV_m[1]+" "+PV_m[2]+" "+PV_m[3];
			  	System.out.println("Best_Estimation_positions= "+Best_Estimation_positions);
			  	System.out.println("MIN= "+MIN[Depth-1]);
				System.out.println("PV_Export= "+PV_Export);
//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 	
				FileWriter_o.write("Depth-1= "+(Depth-1));
			  	FileWriter_o.write('\n'); 	
			  	FileWriter_o.write("Color_Move[Depth-1]= "+Color_Move[Depth-1]);
			  	FileWriter_o.write('\n'); 
				FileWriter_o.write("Best_Estimation_positions= "+Best_Estimation_positions);
			  	FileWriter_o.write('\n'); 
			  	FileWriter_o.write("MIN= "+MIN[Depth-1]);
			  	FileWriter_o.write('\n'); 
			  	FileWriter_o.write("PV_Export= "+PV_Export);
		     	FileWriter_o.write('\n'); 	
		     	FileWriter_o.write('\n'); 
//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 	  
	 */	   	 
	
	/*	  	
//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			  	PV_Export="PV_m= "+PV_m[0]+" "+PV_m[1]+" "+PV_m[2]+" "+PV_m[3];
			  	System.out.println("Color_Move[Depth-1]= "+Color_Move[Depth-1]);
			  	System.out.println("Best_Estimation_positions= "+Best_Estimation_positions);
			  	System.out.println("MAX= "+MAX[Depth-1]);
			  	System.out.println("PV_Export= "+PV_Export);
//	 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 
				FileWriter_o.write("Depth-1= "+(Depth-1));
			  	FileWriter_o.write('\n'); 	
			  	FileWriter_o.write("Color_Move[Depth-1]= "+Color_Move[Depth-1]);
			  	FileWriter_o.write('\n'); 
			  	FileWriter_o.write("Best_Estimation_positions= "+Best_Estimation_positions);
			  	FileWriter_o.write('\n'); 
			  	FileWriter_o.write("MAX= "+MAX[Depth-1]);
			  	FileWriter_o.write('\n'); 
			  	FileWriter_o.write("PV_Export= "+PV_Export);
		     	FileWriter_o.write('\n'); 
		     	FileWriter_o.write('\n');
//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ 	
	 */     	
	
	/*	
	FileWriter_o.write("MAXMAXMAX= ");
	FileWriter_o.write('\n'); 
  	FileWriter_o.write("MAX= "+MAX[Depth-1]);
  	FileWriter_o.write('\n');
  	FileWriter_o.write("MIN= "+MIN[Depth-1]);
  	FileWriter_o.write('\n');
  	
  	//---------------------------------------------------------
	try{
		FileWriter_o.write("����� ��������");
		FileWriter_o.write('\n');
		 }catch(FileNotFoundException e){
	         System.out.println("������ �������� ��������� �����");
	    }catch(IOException e){
	         System.out.println("�������� ������"+ e);
	    }		
//---------------------------------------------------------	   
*/	
	
	
	
	
	
	
}
