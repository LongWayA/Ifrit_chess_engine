/*
 * Created on 21.01.2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package Genie_engine_estimation;

/**
 * @author �����
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Engine_Chek {
	
	private char[][] name_Figure;
	private int[][] color_Figure;
	
 public	Engine_Chek(){}
	
//	==============================================================================
//	�������� ������ ���� � ������ �����
	 public void setName_Color_Figure(char[][] name_Figure,int[][] color_Figure) {
	   this.name_Figure = name_Figure;
	   this.color_Figure = color_Figure;
	 }
//	******************************************************************************



	 
	 
	 
}//class Engine_Chek
